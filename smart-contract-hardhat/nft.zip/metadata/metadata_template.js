metadata_template = {
  name: "",
  description: "",
  image: "",
  attributes: [
    {
      trait_type: "animal",
      value: "",
    },
    {
      trait_type: "preferred name",
      value: "",
    },
    {
      trait_type: "derpiness",
      value: 10,
    },
  ],
};
